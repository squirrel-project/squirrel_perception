/******************************************************************************
 * Copyright (c) 2012 Aitor Aldoma
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 ******************************************************************************/


#ifndef V4R_MODEL_VIEWS_SOURCE_H_
#define V4R_MODEL_VIEWS_SOURCE_H_

#include "source.h"
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>
#include "v4r/common/faat_3d_rec_framework_defines.h"
#include "vtk_model_sampling.h"
#include <vtkTransformPolyDataFilter.h>
#include <pcl/segmentation/supervoxel_clustering.h>
#include <v4r/io/filesystem.h>

namespace v4r
{

    /**
     * \brief Data source class based on partial views from sensor.
     * In this case, the training data is obtained directly from a depth sensor.
     * The filesystem should contain pcd files (representing a view of an object in
     * camera coordinates) and each view needs to be associated with a txt file
     * containing a 4x4 matrix representing the transformation from camera coordinates
     * to a global object coordinates frame.
     * \author Aitor Aldoma
     */

    template<typename Full3DPointT = pcl::PointXYZRGBNormal, typename PointInT = pcl::PointXYZRGB>
      class V4R_EXPORTS ModelOnlySource : public Source<PointInT>
      {
        typedef Source<PointInT> SourceT;
        typedef Model<PointInT> ModelT;
        typedef boost::shared_ptr<ModelT> ModelTPtr;

        using SourceT::path_;
        using SourceT::models_;
        using SourceT::model_scale_;
        using SourceT::load_into_memory_;
        using SourceT::radius_normals_;
        using SourceT::compute_normals_;
        std::string ext_;

        void computeFaces(ModelT & model);

      public:
        ModelOnlySource ()
        {
          load_into_memory_ = false;
          ext_ = "pcd";
        }

        void setExtension(std::string e)
        {
            ext_ = e;
        }

        void
        loadOrGenerate (const std::string & model_path, ModelT & model)
        {
          if(ext_.compare("pcd") == 0)
          {
              std::stringstream full_model;
              full_model << path_ << "/" << model.class_ << "/" << model.id_;
              typename pcl::PointCloud<Full3DPointT>::Ptr modell (new pcl::PointCloud<Full3DPointT>);
              typename pcl::PointCloud<Full3DPointT>::Ptr modell_voxelized (new pcl::PointCloud<Full3DPointT>);
              pcl::io::loadPCDFile(full_model.str(), *modell);

              float voxel_grid_size = 0.001f;
              typename pcl::VoxelGrid<Full3DPointT> grid_;
              grid_.setInputCloud (modell);
              grid_.setLeafSize (voxel_grid_size, voxel_grid_size, voxel_grid_size);
              grid_.setDownsampleAllData (true);
              grid_.filter (*modell_voxelized);

              model.normals_assembled_.reset(new pcl::PointCloud<pcl::Normal>);
              model.assembled_.reset (new pcl::PointCloud<PointInT>);

              pcl::copyPointCloud(*modell_voxelized, *model.assembled_);
              pcl::copyPointCloud(*modell_voxelized, *model.normals_assembled_);

              for(size_t kk=0; kk < model.normals_assembled_->points.size(); kk++)
              {
                  Eigen::Vector3f normal = model.normals_assembled_->points[kk].getNormalVector3fMap();
                  normal.normalize();
                  model.normals_assembled_->points[kk].getNormalVector3fMap() = normal;
              }

              computeFaces(model);

          }
          else if(ext_.compare("ply") == 0)
          {
              typename pcl::PointCloud<PointInT>::Ptr model_cloud(new pcl::PointCloud<PointInT>());
              uniform_sampling<PointInT> (model_path, 100000, *model_cloud, model_scale_);

              float resolution = 0.001f;
              pcl::VoxelGrid<PointInT> grid_;
              grid_.setInputCloud (model_cloud);
              grid_.setLeafSize (resolution, resolution, resolution);
              grid_.setDownsampleAllData(true);

              model.assembled_.reset (new pcl::PointCloud<PointInT>);
              grid_.filter (*(model.assembled_));

              if(compute_normals_)
              {
                std::cout << "Computing normals for ply models... " << radius_normals_ << std::endl;
                model.computeNormalsAssembledCloud(radius_normals_);
                model.setFlipNormalsBasedOnVP(true);
              }
          }
        }
        /**
         * \brief Creates the model representation of the training set, generating views if needed
         */
        void
        generate ()
        {
          models_.clear();
          std::vector < std::string > files = v4r::io::getFilesInDirectory (path_, ".3D_model.pcd", false);
          std::cout << files.size() << std::endl;

          for (size_t i = 0; i < files.size (); i++)
          {
            ModelTPtr m(new ModelT);

            std::vector < std::string > strs;
            boost::split (strs, files[i], boost::is_any_of ("/\\"));

            if (strs.size () == 1)
            {
              m->id_ = strs[0];
            }
            else
            {
              std::stringstream ss;
              for (int j = 0; j < (static_cast<int> (strs.size ()) - 1); j++)
              {
                ss << strs[j];
                if (j != (static_cast<int> (strs.size ()) - 1))
                  ss << "/";
              }

              m->class_ = ss.str ();
              m->id_ = strs[strs.size () - 1];
            }

            std::cout << m->class_ << " . " << m->id_ << std::endl;

            //check which of them have been trained using training_dir and the model_id_
            //load views, poses and self-occlusions for those that exist
            //generate otherwise
            std::string path_model = path_ + "/" + files[i];
            loadOrGenerate (path_model, *m);

            models_.push_back (m);

            //std::cout << files[i] << std::endl;
          }
        }
      };
}

#endif
